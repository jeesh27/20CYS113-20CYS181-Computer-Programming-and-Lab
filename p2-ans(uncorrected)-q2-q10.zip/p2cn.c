#include <stdio.h>
#define complex_numbers{
    struct complexnos{
        float variable[3];
    }cn;
    int main (){
        scanf("%f",&cn.variables[1]);
        scanf("%f",&cn.variable[2]);
        printf("3n",variable][1]);
        printf("2x",variable[2]);
        float product=variable[1]*variable[2];
        printf("%f",product);
}

    return 0;
}
