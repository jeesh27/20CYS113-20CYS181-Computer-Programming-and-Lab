#include <stdio.h>
int main (){
	int i,j;
	printf("1");
	for(i=1,i<=35,i++)
		(j=0,i=i+j,j++){
