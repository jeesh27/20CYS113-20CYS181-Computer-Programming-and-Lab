# Enter the divident
print("Enter the divident")
divident = int(input())

# Enter the divisor
print("Enter the divisor")
divisor = int(input())
quotient = float(divident) / divisor
print("The Quotient is" + str(quotient))
remainder = divident - divisor * quotient

# The remainder is
print("The Remainder is" + str(remainder))
