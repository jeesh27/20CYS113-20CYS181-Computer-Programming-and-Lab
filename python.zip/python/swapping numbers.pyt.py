print("Enter the value of 1st number-a")
a = int(input())
print("Enter the value of 2nd number-b")
b = int(input())

# we swap the numbers using some operations
a = a + b
b = a - b
a = a - b

# now the numbers are swapped
print("The new a is" + str(a))
print("the new b is" + str(b))
