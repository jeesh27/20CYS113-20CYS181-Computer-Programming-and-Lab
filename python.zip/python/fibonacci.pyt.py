def fibonacci(n):
    c = 1
    i = 1
    if n == 0:
        pass
    else:
        a = 0
        b = 1
        while i <= n:
            c = a + b
            print(str(a) + " + " + str(b) + " = " + str(c))
            a = b
            b = c
            i = i + 1
        print("no value")
    
    return a

# Main
n = int(input())
print("The required fibonacci series is ")
fib = fibonacci(n)
