# This is the Account Number
accNumber = 123456

# This is your pin
pin1 = 1234

# Initial balance
balance = 5000
print("Welcome to our Bank")
print("Enter your account number")
accNumber = int(input())
print("Enter your Name")
name = input()
print("Enter your Pin Number")
pin = int(input())
if pin == pin1:
    
    # Allows to withdraw cash if the entered pin is correct
    print("Enter the amount you want to withdraw")
    amount = int(input())
    if amount <= balance:
        print("Please collect your cash")
        balance = balance - amount
        
        # This is your current balance
        print("your current Balance is" + str(balance))
        print("Transaction successful")
        print("Thank you for using our Bank")
    else:
        print("Sorry, insufficient Balance")
        print("Transaction cancelled")
        print("Thank you for using our Bank")
else:
    
    # if the entered pin is wrong
    print("Please recheck the pin and try again")
    print("Transaction Cancelled")
    print("Thank you for using our Bank")
